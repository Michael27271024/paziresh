export interface Patient {
  id: string;
  nationalId: string;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  address?: string;
  birthDate?: string;
  gender: 'male' | 'female';
  insuranceType?: 'social' | 'health' | 'military' | 'military_disabled' | 'bank' | 'none';
  insuranceNumber?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface MedicalItem {
  id: string;
  name: string;
  price: number;
  category: 'medicine' | 'service';
  description?: string;
}

export interface Invoice {
  id: string;
  patientId: string;
  items: InvoiceItem[];
  totalAmount: number;
  paymentStatus: 'pending' | 'paid' | 'cancelled';
  createdAt: Date;
  doctorCode?: string;
}

export interface InvoiceItem {
  itemId: string;
  itemName: string;
  quantity: number;
  unitPrice: number;
  insuranceShare: number;
  totalPrice: number;
}

export interface User {
  id: string;
  username: string;
  role: 'admin' | 'doctor';
  doctorCode?: string;
  createdAt: Date;
}