import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Patient, Invoice } from '@/types';
import { Users, FileText, DollarSign, Clock, TrendingUp, Shield } from 'lucide-react';

interface DashboardProps {
  patients: Patient[];
  invoices: Invoice[];
}

const Dashboard: React.FC<DashboardProps> = ({ patients, invoices }) => {
  const totalRevenue = invoices.reduce((sum, invoice) => sum + invoice.totalAmount, 0);
  const paidInvoices = invoices.filter(inv => inv.paymentStatus === 'paid');
  const pendingInvoices = invoices.filter(inv => inv.paymentStatus === 'pending');
  
  const insuranceStats = patients.reduce((acc, patient) => {
    const type = patient.insuranceType || 'none';
    acc[type] = (acc[type] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const todayInvoices = invoices.filter(invoice => {
    const today = new Date();
    const invoiceDate = new Date(invoice.createdAt);
    return invoiceDate.toDateString() === today.toDateString();
  }).length;

  const getInsuranceLabel = (type: string) => {
    switch (type) {
      case 'social': return 'تامین اجتماعی';
      case 'health': return 'بیمه سلامت';
      case 'military': return 'نیروهای مسلح';
      case 'none': return 'فاقد بیمه';
      default: return 'نامشخص';
    }
  };

  const stats = [
    {
      title: 'کل بیماران',
      value: patients.length.toString(),
      icon: Users,
      gradient: 'bg-gradient-primary',
      description: 'تعداد کل بیماران ثبت شده'
    },
    {
      title: 'فاکتورهای امروز',
      value: todayInvoices.toString(),
      icon: Clock,
      gradient: 'bg-gradient-secondary',
      description: 'فاکتورهای صادر شده امروز'
    },
    {
      title: 'کل فاکتورها',
      value: invoices.length.toString(),
      icon: FileText,
      gradient: 'bg-blue-500',
      description: 'تعداد کل فاکتورهای صادر شده'
    },
    {
      title: 'درآمد کل',
      value: `${totalRevenue.toLocaleString()} ریال`,
      icon: DollarSign,
      gradient: 'bg-green-500',
      description: 'مجموع درآمد از تمام فاکتورها'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="shadow-card hover:shadow-medical transition-all">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">
                      {stat.title}
                    </p>
                    <p className="text-2xl font-bold text-foreground">
                      {stat.value}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {stat.description}
                    </p>
                  </div>
                  <div className={`w-12 h-12 ${stat.gradient} rounded-full flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Payment Status */}
        <Card className="shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center text-right">
              <TrendingUp className="w-5 h-5 ml-2" />
              وضعیت پرداخت فاکتورها
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-green-50 rounded">
                <span className="text-green-800 font-medium">پرداخت شده</span>
                <div className="text-left">
                  <span className="text-green-600 font-bold">{paidInvoices.length}</span>
                  <span className="text-sm text-green-600 block">
                    {paidInvoices.reduce((sum, inv) => sum + inv.totalAmount, 0).toLocaleString()} ریال
                  </span>
                </div>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-yellow-50 rounded">
                <span className="text-yellow-800 font-medium">در انتظار پرداخت</span>
                <div className="text-left">
                  <span className="text-yellow-600 font-bold">{pendingInvoices.length}</span>
                  <span className="text-sm text-yellow-600 block">
                    {pendingInvoices.reduce((sum, inv) => sum + inv.totalAmount, 0).toLocaleString()} ریال
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Insurance Statistics */}
        <Card className="shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center text-right">
              <Shield className="w-5 h-5 ml-2" />
              آمار بیمه بیماران
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {Object.entries(insuranceStats).map(([type, count]) => (
                <div key={type} className="flex justify-between items-center p-3 bg-muted/50 rounded">
                  <span className="font-medium">{getInsuranceLabel(type)}</span>
                  <span className="font-bold text-primary">{count} نفر</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card className="shadow-card">
        <CardHeader>
          <CardTitle className="text-right">آخرین فعالیت‌ها</CardTitle>
        </CardHeader>
        <CardContent>
          {invoices.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              هنوز فعالیتی ثبت نشده است
            </div>
          ) : (
            <div className="space-y-3">
              {invoices.slice(-5).reverse().map((invoice) => {
                const patient = patients.find(p => p.id === invoice.patientId);
                return (
                  <div key={invoice.id} className="flex items-center justify-between p-3 border rounded">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center">
                        <FileText className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <span className="font-medium">
                          فاکتور برای {patient?.firstName} {patient?.lastName}
                        </span>
                        <div className="text-sm text-muted-foreground">
                          {new Date(invoice.createdAt).toLocaleDateString('fa-IR')}
                        </div>
                      </div>
                    </div>
                    <div className="text-left">
                      <span className="font-semibold">{invoice.totalAmount.toLocaleString()} ریال</span>
                      <div className="text-sm">
                        <span className={`px-2 py-1 rounded text-xs ${
                          invoice.paymentStatus === 'paid' 
                            ? 'bg-green-100 text-green-800'
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {invoice.paymentStatus === 'paid' ? 'پرداخت شده' : 'در انتظار'}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;