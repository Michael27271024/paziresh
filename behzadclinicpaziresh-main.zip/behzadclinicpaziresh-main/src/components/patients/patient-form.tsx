import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Patient } from '@/types';
import { User, Phone, MapPin, Calendar, Shield } from 'lucide-react';

interface PatientFormProps {
  onSubmit: (patient: Omit<Patient, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onCancel: () => void;
}

const PatientForm: React.FC<PatientFormProps> = ({ onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    nationalId: '',
    firstName: '',
    lastName: '',
    phoneNumber: '',
    address: '',
    birthDate: '',
    gender: '' as 'male' | 'female' | '',
    insuranceType: '' as 'social' | 'health' | 'military' | 'none' | '',
    insuranceNumber: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.nationalId && formData.firstName && formData.lastName && formData.phoneNumber && formData.gender) {
      onSubmit({
        ...formData,
        gender: formData.gender as 'male' | 'female',
        insuranceType: formData.insuranceType as 'social' | 'health' | 'military' | 'none' || 'none',
      });
    }
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Card className="shadow-card">
      <CardHeader>
        <CardTitle className="flex items-center text-right">
          <User className="w-5 h-5 ml-2" />
          ثبت بیمار جدید
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="nationalId">کد ملی *</Label>
              <Input
                id="nationalId"
                value={formData.nationalId}
                onChange={(e) => handleChange('nationalId', e.target.value)}
                placeholder="1234567890"
                className="text-right"
                dir="rtl"
                required
                maxLength={10}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="firstName">نام *</Label>
              <Input
                id="firstName"
                value={formData.firstName}
                onChange={(e) => handleChange('firstName', e.target.value)}
                placeholder="نام بیمار"  
                className="text-right"
                dir="rtl"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="lastName">نام خانوادگی *</Label>
              <Input
                id="lastName"
                value={formData.lastName}
                onChange={(e) => handleChange('lastName', e.target.value)}
                placeholder="نام خانوادگی بیمار"
                className="text-right"
                dir="rtl"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phoneNumber">شماره تماس *</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="phoneNumber"
                  value={formData.phoneNumber}
                  onChange={(e) => handleChange('phoneNumber', e.target.value)}
                  placeholder="09123456789"
                  className="text-right pl-10"
                  dir="rtl"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="birthDate">تاریخ تولد (شمسی)</Label>
              <div className="relative">
                <Calendar className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="birthDate"
                  type="text"
                  value={formData.birthDate}
                  onChange={(e) => handleChange('birthDate', e.target.value)}
                  placeholder="مثال: 1370/05/15"
                  className="pl-10 text-right"
                  dir="rtl"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="gender">جنسیت *</Label>
              <Select value={formData.gender} onValueChange={(value) => handleChange('gender', value)}>
                <SelectTrigger className="text-right">
                  <SelectValue placeholder="انتخاب جنسیت" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="male">مرد</SelectItem>
                  <SelectItem value="female">زن</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="insuranceType">نوع بیمه</Label>
              <div className="relative">
                <Shield className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Select value={formData.insuranceType} onValueChange={(value) => handleChange('insuranceType', value)}>
                  <SelectTrigger className="text-right pl-10">
                    <SelectValue placeholder="انتخاب نوع بیمه" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="social">تامین اجتماعی</SelectItem>
                    <SelectItem value="health">بیمه سلامت</SelectItem>
                    <SelectItem value="military">نیروهای مسلح</SelectItem>
                    <SelectItem value="none">فاقد بیمه</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="insuranceNumber">شماره بیمه</Label>
              <Input
                id="insuranceNumber"
                value={formData.insuranceNumber}
                onChange={(e) => handleChange('insuranceNumber', e.target.value)}
                placeholder="شماره بیمه (در صورت وجود)"
                className="text-right"
                dir="rtl"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="address">آدرس</Label>
            <div className="relative">
              <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Textarea
                id="address"
                value={formData.address}
                onChange={(e) => handleChange('address', e.target.value)}
                placeholder="آدرس کامل بیمار"
                className="text-right pl-10"
                dir="rtl"
                rows={3}
              />
            </div>
          </div>

          <div className="flex justify-end space-x-2 space-x-reverse pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>
              لغو
            </Button>
            <Button 
              type="submit" 
              className="bg-gradient-primary hover:opacity-90 text-white"
            >
              ثبت بیمار
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default PatientForm;