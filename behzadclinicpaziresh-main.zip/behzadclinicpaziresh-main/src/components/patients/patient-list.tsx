import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Patient } from '@/types';
import { Search, Plus, User, Phone, Shield, Edit, Trash2 } from 'lucide-react';

interface PatientListProps {
  patients: Patient[];
  onAddPatient: () => void;
  onEditPatient: (patient: Patient) => void;
  onDeletePatient: (patientId: string) => void;
  onSelectPatient: (patient: Patient) => void;
}

const PatientList: React.FC<PatientListProps> = ({
  patients,
  onAddPatient,
  onEditPatient,
  onDeletePatient,
  onSelectPatient,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredPatients = patients.filter(patient =>
    patient.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    patient.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    patient.nationalId.includes(searchTerm) ||
    patient.phoneNumber.includes(searchTerm)
  );

  const getInsuranceLabel = (type: string) => {
    switch (type) {
      case 'social': return 'تامین اجتماعی';
      case 'health': return 'بیمه سلامت';
      case 'military': return 'نیروهای مسلح';
      case 'none': return 'فاقد بیمه';
      default: return 'نامشخص';
    }
  };

  const getInsuranceColor = (type: string) => {
    switch (type) {
      case 'social': return 'bg-blue-100 text-blue-800';
      case 'health': return 'bg-green-100 text-green-800';      
      case 'military': return 'bg-purple-100 text-purple-800';
      case 'none': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="shadow-card">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center text-right">
          <User className="w-5 h-5 ml-2" />
          لیست بیماران ({filteredPatients.length})
        </CardTitle>
        <Button 
          onClick={onAddPatient}
          className="bg-gradient-primary hover:opacity-90 text-white"
        >
          <Plus className="w-4 h-4 ml-2" />
          بیمار جدید
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute right-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="جستجو بر اساس نام، کد ملی یا شماره تماس..."
              className="text-right pr-10"
              dir="rtl"
            />
          </div>

          {/* Patient List */}
          <div className="space-y-3">
            {filteredPatients.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                {searchTerm ? 'بیماری با این مشخصات یافت نشد' : 'هنوز بیماری ثبت نشده است'}
              </div>
            ) : (
              filteredPatients.map((patient) => (
                <Card
                  key={patient.id}
                  className="p-4 hover:shadow-md transition-all cursor-pointer border-l-4 border-l-primary/20"
                  onClick={() => onSelectPatient(patient)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-primary rounded-full flex items-center justify-center">
                          <User className="w-5 h-5 text-white" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-foreground">
                            {patient.firstName} {patient.lastName}
                          </h3>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                            <span>کد ملی: {patient.nationalId}</span>
                            <span className="flex items-center gap-1">
                              <Phone className="w-3 h-3" />
                              {patient.phoneNumber}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Badge className={`${getInsuranceColor(patient.insuranceType || 'none')} border-0`}>
                        <Shield className="w-3 h-3 ml-1" />
                        {getInsuranceLabel(patient.insuranceType || 'none')}
                      </Badge>
                      
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            onEditPatient(patient);
                          }}
                          className="h-8 w-8 p-0"
                        >
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeletePatient(patient.id);
                          }}
                          className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default PatientList;