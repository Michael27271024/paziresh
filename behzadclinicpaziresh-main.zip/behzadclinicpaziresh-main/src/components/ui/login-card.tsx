import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './card';
import { Button } from './button';
import { Input } from './input';
import { Label } from './label';
import { useToast } from '@/hooks/use-toast';
import { Stethoscope, Lock, Moon, Sun, Laptop } from 'lucide-react';
import { useTheme } from '../theme-provider';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './dropdown-menu';

interface LoginCardProps {
  onLogin: (success: boolean) => void;
}

const LoginCard: React.FC<LoginCardProps> = ({ onLogin }) => {
  const [password, setPassword] = useState('');
  const [doctorNationalId, setDoctorNationalId] = useState('');
  const [doctorCode, setDoctorCode] = useState('');
  const [step, setStep] = useState<'admin' | 'doctor'>('admin');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { setTheme } = useTheme();

  const handleAdminSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    setTimeout(() => {
      if (password === 'avesta27admin') {
        setStep('doctor');
        toast({
          title: "احراز هویت مدیریت تایید شد",
          description: "اکنون کد ملی پزشک را وارد کنید",
        });
      } else {
        toast({
          title: "خطا در ورود",
          description: "رمز عبور مدیریت اشتباه است",
          variant: "destructive",
        });
      }
      setIsLoading(false);
    }, 1000);
  };

  const handleDoctorSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    setTimeout(() => {
      if (doctorNationalId.length === 10 && doctorCode.length >= 4) {
        onLogin(true);
        toast({
          title: "احراز هویت پزشک تایید شد",
          description: `دکتر با کد ملی ${doctorNationalId} وارد سیستم شد`,
        });
      } else {
        toast({
          title: "خطا در احراز هویت پزشک",
          description: "کد ملی یا کد تایید پزشک صحیح نیست",
          variant: "destructive",
        });
      }
      setIsLoading(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-background flex items-center justify-center p-4">
      <div className="absolute top-4 right-4">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="icon">
              <Sun className="h-[1.2rem] w-[1.2rem] rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-[1.2rem] w-[1.2rem] rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
              <span className="sr-only">Toggle theme</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => setTheme("light")}>
              <Sun className="mr-2 h-4 w-4" />
              روشن
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setTheme("dark")}>
              <Moon className="mr-2 h-4 w-4" />
              تیره
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setTheme("system")}>
              <Laptop className="mr-2 h-4 w-4" />
              سیستم
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <Card className="w-full max-w-md shadow-medical border-0 bg-card/80 backdrop-blur-sm">
        <CardHeader className="text-center space-y-2">
          <div className="flex justify-center">
            <div className="p-3 bg-gradient-primary rounded-full shadow-lg">
              <Stethoscope className="w-8 h-8 text-primary-foreground" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            سیستم مدیریت درمانگاه بهزاد
          </CardTitle>
          <CardDescription className="text-muted-foreground">
            {step === 'admin' ? 'برای ورود رمز مدیریت را وارد کنید' : 'کد ملی و کد تایید پزشک را وارد کنید'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {step === 'admin' ? (
            <form onSubmit={handleAdminSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="password" className="text-right flex items-center">
                  <Lock className="w-4 h-4 ml-1" />
                  رمز عبور مدیریت
                </Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="رمز عبور مدیریت را وارد کنید"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="text-right"
                  required
                />
              </div>
              <Button 
                type="submit" 
                className="w-full bg-gradient-primary hover:opacity-90 transition-all"
                disabled={isLoading}
              >
                {isLoading ? 'در حال تایید...' : 'تایید مدیریت'}
              </Button>
            </form>
          ) : (
            <form onSubmit={handleDoctorSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="doctorNationalId" className="text-right flex items-center">
                  <Stethoscope className="w-4 h-4 ml-1" />
                  کد ملی پزشک
                </Label>
                <Input
                  id="doctorNationalId"
                  type="text"
                  placeholder="کد ملی ۱۰ رقمی پزشک"
                  value={doctorNationalId}
                  onChange={(e) => setDoctorNationalId(e.target.value)}
                  className="text-right"
                  maxLength={10}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="doctorCode" className="text-right flex items-center">
                  <Lock className="w-4 h-4 ml-1" />
                  کد تایید پیامکی
                </Label>
                <Input
                  id="doctorCode"
                  type="text"
                  placeholder="کد دریافتی از پیامک"
                  value={doctorCode}
                  onChange={(e) => setDoctorCode(e.target.value)}
                  className="text-right"
                  required
                />
              </div>
              <div className="flex space-x-2 space-x-reverse">
                <Button 
                  type="button"
                  variant="outline"
                  onClick={() => setStep('admin')}
                  className="flex-1"
                >
                  بازگشت
                </Button>
                <Button 
                  type="submit" 
                  className="flex-1 bg-gradient-primary hover:opacity-90 transition-all"
                  disabled={isLoading}
                >
                  {isLoading ? 'در حال تایید...' : 'ورود به سیستم'}
                </Button>
              </div>
            </form>
          )}
        </CardContent>
      </Card>
      
      <div className="absolute bottom-4 left-4 right-4 text-center">
        <p className="text-xs text-muted-foreground">
          تمام حقوق محفوظ به درمانگاه بهزاد - سازنده: اوستا حسن زاده
        </p>
      </div>
    </div>
  );
};

export default LoginCard;