import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useTheme } from '../theme-provider';
import { 
  FileText, 
  BarChart3, 
  Stethoscope,
  Moon,
  Sun,
  Laptop
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface MainLayoutProps {
  children: React.ReactNode;
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const MainLayout: React.FC<MainLayoutProps> = ({ 
  children, 
  activeTab, 
  onTabChange
}) => {
  const { setTheme } = useTheme();
  const tabs = [
    { id: 'invoice', label: 'تعرفه', icon: FileText },
    { id: 'management', label: 'مدیریت', icon: BarChart3 },
  ];

  return (
    <div className="min-h-screen bg-gradient-background" dir="rtl">
      {/* Header */}
      <header className="bg-card/80 backdrop-blur-sm shadow-card border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 space-x-reverse">
              <div className="p-2 bg-gradient-primary rounded-lg shadow-lg">
                <Stethoscope className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">درمانگاه بهزاد</h1>
                <p className="text-sm text-muted-foreground">سیستم مدیریت بیماران</p>
              </div>
            </div>
            <div className="flex items-center space-x-2 space-x-reverse">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                    <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => setTheme("light")}>
                    <Sun className="mr-2 h-4 w-4" />
                    روشن
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setTheme("dark")}>
                    <Moon className="mr-2 h-4 w-4" />
                    تیره
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setTheme("system")}>
                    <Laptop className="mr-2 h-4 w-4" />
                    سیستم
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <Card className="lg:col-span-1 p-4 h-fit shadow-card bg-card/80 backdrop-blur-sm">
            <nav className="space-y-2">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <Button
                    key={tab.id}
                    variant={activeTab === tab.id ? "default" : "ghost"}
                    className={`w-full justify-start text-right ${
                      activeTab === tab.id 
                        ? 'bg-gradient-primary text-white' 
                        : 'hover:bg-muted'
                    }`}
                    onClick={() => onTabChange(tab.id)}
                  >
                    <Icon className="w-4 h-4 ml-2" />
                    {tab.label}
                  </Button>
                );
              })}
            </nav>
          </Card>

          {/* Main content */}
          <div className="lg:col-span-3">
            <div className="bg-card/80 backdrop-blur-sm rounded-lg p-6 shadow-card border">
              {children}
            </div>
          </div>
        </div>
        
        <footer className="mt-8 py-4 text-center border-t border-border">
          <p className="text-xs text-muted-foreground">
            تمام حقوق محفوظ به درمانگاه بهزاد - سازنده: اوستا حسن زاده
          </p>
        </footer>
      </div>
    </div>
  );
};

export default MainLayout;