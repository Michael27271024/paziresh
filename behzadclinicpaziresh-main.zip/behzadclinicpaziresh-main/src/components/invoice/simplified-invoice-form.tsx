import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { MedicalItem, InvoiceItem, Invoice } from '@/types';
import { medicalItems } from '@/data/medicalItems';
import { FileText, Plus, Minus, Trash2, Calculator, Printer, CreditCard, UserCheck } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { generateDailyInvoiceNumber, calculateInsuranceShare, getInsuranceTypeName } from '@/utils/invoiceUtils';

interface SimplifiedInvoiceFormProps {
  onSaveInvoice: (invoice: Omit<Invoice, 'id' | 'createdAt'>) => void;
  receptionist: string;
}

const SimplifiedInvoiceForm: React.FC<SimplifiedInvoiceFormProps> = ({ onSaveInvoice, receptionist }) => {
  const [patientInfo, setPatientInfo] = useState({
    nationalId: '',
    firstName: '',
    lastName: '',
    birthDate: '',
    insuranceType: 'none' as 'social' | 'health' | 'military' | 'military_disabled' | 'bank' | 'none'
  });
  const [selectedDoctor, setSelectedDoctor] = useState('');
  const [invoiceItems, setInvoiceItems] = useState<InvoiceItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const { toast } = useToast();

  const filteredItems = medicalItems.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const addItem = (item: MedicalItem) => {
    const existingItem = invoiceItems.find(invItem => invItem.itemId === item.id);
    
    if (existingItem) {
      setInvoiceItems(prevItems =>
        prevItems.map(invItem =>
          invItem.itemId === item.id
            ? {
                ...invItem,
                quantity: invItem.quantity + 1,
                totalPrice: ((invItem.quantity + 1) * invItem.unitPrice) - (invItem.insuranceShare * (invItem.quantity + 1))
              }
            : invItem
        )
      );
    } else {
      const insuranceShare = calculateInsuranceShare(item.name, patientInfo.insuranceType);
      const newItem: InvoiceItem = {
        itemId: item.id,
        itemName: item.name,
        quantity: 1,
        unitPrice: item.price,
        insuranceShare: insuranceShare,
        totalPrice: item.price - insuranceShare
      };
      setInvoiceItems(prev => [...prev, newItem]);
    }
    
    setSearchTerm('');
    toast({
      title: "آیتم اضافه شد",
      description: `${item.name} به فاکتور اضافه شد`,
    });
  };

  const updateQuantity = (itemId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeItem(itemId);
      return;
    }

    setInvoiceItems(prevItems =>
      prevItems.map(item =>
        item.itemId === itemId
          ? {
              ...item,
              quantity: newQuantity,
              totalPrice: (newQuantity * item.unitPrice) - (item.insuranceShare * newQuantity)
            }
          : item
      )
    );
  };

  const removeItem = (itemId: string) => {
    setInvoiceItems(prev => prev.filter(item => item.itemId !== itemId));
  };

  const calculateTotal = () => {
    return invoiceItems.reduce((sum, item) => sum + item.totalPrice, 0);
  };

  const sendToPOS = async (amount: number) => {
    // Simulate POS terminal communication
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(true);
      }, 1500);
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!patientInfo.firstName || !patientInfo.lastName || !patientInfo.nationalId) {
      toast({
        title: "خطا",
        description: "لطفاً اطلاعات بیمار را کامل وارد کنید",
        variant: "destructive"
      });
      return;
    }

    if (!selectedDoctor) {
      toast({
        title: "خطا",
        description: "لطفاً پزشک معالج را انتخاب کنید",
        variant: "destructive"
      });
      return;
    }

    if (invoiceItems.length === 0) {
      toast({
        title: "خطا", 
        description: "لطفاً حداقل یک آیتم به فاکتور اضافه کنید",
        variant: "destructive"
      });
      return;
    }

    const total = calculateTotal();
    
    toast({
      title: "در حال ارسال به کارتخوان...",
      description: `مبلغ ${total.toLocaleString()} ریال`,
    });

    try {
      await sendToPOS(total);
      
      // Save invoice data
      const invoiceData = {
        patientId: patientInfo.nationalId,
        items: invoiceItems,
        totalAmount: total,
        paymentStatus: 'paid' as const,
      };
      
      onSaveInvoice(invoiceData);
      
      toast({
        title: "پرداخت موفق! 💳",
        description: `مبلغ ${total.toLocaleString()} ریال با موفقیت پرداخت شد`,
      });

      // Auto print after payment
      setTimeout(() => {
        handlePrint();
      }, 1000);
      
      // Reset form
      setPatientInfo({
        nationalId: '',
        firstName: '',
        lastName: '',
        birthDate: '',
        insuranceType: 'none'
      });
      setSelectedDoctor('');
      setInvoiceItems([]);
    } catch (error) {
      toast({
        title: "خطا در پرداخت",
        description: "لطفاً دوباره تلاش کنید",
        variant: "destructive"
      });
    }
  };

  const handlePrint = () => {
    if (!patientInfo.firstName || invoiceItems.length === 0 || !selectedDoctor) {
      toast({
        title: "خطا",
        description: "برای چاپ فاکتور، ابتدا تمام اطلاعات لازم را وارد کنید",
        variant: "destructive"
      });
      return;
    }

    const invoiceNumber = generateDailyInvoiceNumber();
    const totalAmount = calculateTotal();
    const totalInsuranceShare = invoiceItems.reduce((sum, item) => sum + (item.insuranceShare * item.quantity), 0);

    // Create print content
    const printContent = `
      <!DOCTYPE html>
      <html dir="rtl" lang="fa">
      <head>
        <meta charset="UTF-8">
        <title>فاکتور - درمانگاه عمومی بهزاد</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 20px; direction: rtl; }
          .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; }
          .patient-info { margin-bottom: 20px; }
          .items-table { width: 100%; border-collapse: collapse; }
          .items-table th, .items-table td { border: 1px solid #333; padding: 8px; text-align: center; }
          .total { font-weight: bold; font-size: 18px; text-align: left; margin-top: 20px; }
          .footer { margin-top: 30px; text-align: center; font-size: 12px; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>درمانگاه عمومی بهزاد</h1>
          <p>فاکتور خدمات درمانی</p>
          <p>شماره فاکتور: ${invoiceNumber}</p>
          <p>تاریخ: ${new Date().toLocaleDateString('fa-IR')}</p>
          <p>پذیرش دهنده: ${receptionist}</p>
          <p>پزشک معالج: ${selectedDoctor}</p>
        </div>
        
        <div class="patient-info">
          <h3>اطلاعات بیمار:</h3>
          <p><strong>نام:</strong> ${patientInfo.firstName} ${patientInfo.lastName}</p>
          <p><strong>کد ملی:</strong> ${patientInfo.nationalId}</p>
          <p><strong>نوع بیمه:</strong> ${getInsuranceTypeName(patientInfo.insuranceType)}</p>
          ${patientInfo.birthDate ? `<p><strong>تاریخ تولد:</strong> ${patientInfo.birthDate}</p>` : ''}
        </div>

        <table class="items-table">
          <thead>
            <tr>
              <th>شرح خدمت/کالا</th>
              <th>تعداد</th>
              <th>قیمت واحد (ریال)</th>
              <th>سهم بیمه (ریال)</th>
              <th>مبلغ (ریال)</th>
            </tr>
          </thead>
          <tbody>
            ${invoiceItems.map((item) => `
              <tr>
                <td>${item.itemName}</td>
                <td>${item.quantity}</td>
                <td>${item.unitPrice.toLocaleString()}</td>
                <td>${(item.insuranceShare * item.quantity).toLocaleString()}</td>
                <td>${item.totalPrice.toLocaleString()}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <div class="total">
          <p>مجموع کل: ${(totalAmount + totalInsuranceShare).toLocaleString()} ریال</p>
          ${totalInsuranceShare > 0 ? `<p>کل سهم بیمه: ${totalInsuranceShare.toLocaleString()} ریال</p>` : ''}
          <p>مبلغ قابل پرداخت: ${totalAmount.toLocaleString()} ریال</p>
        </div>

        <div class="footer">
          <p>درمانگاه عمومی بهزاد - سیستم مدیریت بیماران</p>
          <p>پرداخت شده</p>
        </div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card className="shadow-card">
        <CardHeader>
          <CardTitle className="flex items-center text-right">
            <FileText className="w-5 h-5 ml-2" />
            صدور فاکتور
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Doctor Selection */}
            <div className="space-y-2">
              <Label htmlFor="doctor" className="flex items-center">
                <UserCheck className="w-4 h-4 ml-1" />
                پزشک معالج *
              </Label>
              <Select value={selectedDoctor} onValueChange={setSelectedDoctor}>
                <SelectTrigger className="text-right" dir="rtl">
                  <SelectValue placeholder="پزشک معالج را انتخاب کنید" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="دکتر امید حسن زاده بندپی">دکتر امید حسن زاده بندپی</SelectItem>
                  <SelectItem value="دکتر داود زنده دل">دکتر داود زنده دل</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Patient Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="nationalId">شماره ملی *</Label>
                <Input
                  id="nationalId"
                  value={patientInfo.nationalId}
                  onChange={(e) => setPatientInfo(prev => ({ ...prev, nationalId: e.target.value }))}
                  placeholder="شماره ملی بیمار"
                  className="text-right"
                  dir="rtl"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="birthDate">تاریخ تولد (شمسی)</Label>
                <Input
                  id="birthDate"
                  type="text"
                  value={patientInfo.birthDate}
                  onChange={(e) => setPatientInfo(prev => ({ ...prev, birthDate: e.target.value }))}
                  placeholder="مثال: 1370/05/15"
                  className="text-right"
                  dir="rtl"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="firstName">نام *</Label>
                <Input
                  id="firstName"
                  value={patientInfo.firstName}
                  onChange={(e) => setPatientInfo(prev => ({ ...prev, firstName: e.target.value }))}
                  placeholder="نام بیمار"
                  className="text-right"
                  dir="rtl"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="insuranceType">نوع بیمه *</Label>
                <Select 
                  value={patientInfo.insuranceType} 
                  onValueChange={(value) => setPatientInfo(prev => ({ ...prev, insuranceType: value as any }))}
                >
                  <SelectTrigger className="text-right" dir="rtl">
                    <SelectValue placeholder="نوع بیمه را انتخاب کنید" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">فاقد بیمه</SelectItem>
                    <SelectItem value="social">تامین اجتماعی</SelectItem>
                    <SelectItem value="health">سلامت</SelectItem>
                    <SelectItem value="military">نیروهای مسلح</SelectItem>
                    <SelectItem value="military_disabled">نیروهای مسلح جانباز</SelectItem>
                    <SelectItem value="bank">بانک ها</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">نام خانوادگی *</Label>
                <Input
                  id="lastName"
                  value={patientInfo.lastName}
                  onChange={(e) => setPatientInfo(prev => ({ ...prev, lastName: e.target.value }))}
                  placeholder="نام خانوادگی بیمار"
                  className="text-right"
                  dir="rtl"
                  required
                />
              </div>
            </div>

            {/* Add Items */}
            <div className="space-y-2">
              <Label>جستجو و اضافه کردن خدمات/کالا</Label>
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="نام کالا یا خدمت را جستجو کنید..."
                className="text-right"
                dir="rtl"
              />
              
              {searchTerm && (
                <Card className="max-h-48 overflow-y-auto">
                  <CardContent className="p-2">
                    {filteredItems.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between p-2 hover:bg-muted rounded cursor-pointer"
                        onClick={() => addItem(item)}
                      >
                        <div>
                          <span className="font-medium">{item.name}</span>
                          <Badge variant="outline" className="mr-2">
                            {item.category === 'medicine' ? 'کالا' : 'خدمت'}
                          </Badge>
                        </div>
                        <span className="font-semibold">{item.price.toLocaleString()} ریال</span>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Invoice Items */}
            {invoiceItems.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">آیتم‌های فاکتور</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {invoiceItems.map((item) => (
                    <div key={item.itemId} className="flex items-center justify-between p-3 border rounded">
                      <div className="flex-1">
                        <span className="font-medium">{item.itemName}</span>
                        <div className="text-sm text-muted-foreground">
                          قیمت واحد: {item.unitPrice.toLocaleString()} ریال
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          onClick={() => updateQuantity(item.itemId, item.quantity - 1)}
                        >
                          <Minus className="w-3 h-3" />
                        </Button>
                        <span className="w-8 text-center">{item.quantity}</span>
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          onClick={() => updateQuantity(item.itemId, item.quantity + 1)}
                        >
                          <Plus className="w-3 h-3" />
                        </Button>
                        <span className="w-20 text-left font-semibold text-sm">
                          {item.insuranceShare.toLocaleString()}
                        </span>
                        <span className="w-20 text-left font-semibold">
                          {item.totalPrice.toLocaleString()}
                        </span>
                        <Button
                          type="button"
                          size="sm"
                          variant="ghost"
                          onClick={() => removeItem(item.itemId)}
                          className="text-destructive"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                  
                  <div className="pt-4 border-t space-y-2">
                    <div className="flex justify-between items-center font-bold text-lg">
                      <span>مجموع کل:</span>
                      <span>{calculateTotal().toLocaleString()} ریال</span>
                    </div>
                    {patientInfo.insuranceType !== 'none' && (
                      <div className="flex justify-between items-center text-sm text-muted-foreground">
                        <span>کل سهم بیمه ({getInsuranceTypeName(patientInfo.insuranceType)}):</span>
                        <span>{invoiceItems.reduce((sum, item) => sum + (item.insuranceShare * item.quantity), 0).toLocaleString()} ریال</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Actions */}
            <div className="flex gap-2 justify-end">
              <Button
                type="button"
                variant="outline"
                onClick={handlePrint}
                disabled={!patientInfo.firstName || invoiceItems.length === 0 || !selectedDoctor}
              >
                <Printer className="w-4 h-4 ml-2" />
                چاپ فاکتور
              </Button>
              <Button
                type="submit"
                className="bg-gradient-primary hover:opacity-90 text-white"
                disabled={!patientInfo.firstName || invoiceItems.length === 0 || !selectedDoctor}
              >
                <CreditCard className="w-4 h-4 ml-2" />
                پرداخت و ثبت فاکتور
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default SimplifiedInvoiceForm;