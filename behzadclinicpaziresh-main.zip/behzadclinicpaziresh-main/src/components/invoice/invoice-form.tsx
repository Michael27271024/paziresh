import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Patient, MedicalItem, Invoice, InvoiceItem } from '@/types';
import { medicalItems } from '@/data/medicalItems';
import { FileText, Plus, Minus, Trash2, Calculator, Printer, User, Shield } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface InvoiceFormProps {
  patients: Patient[];
  onSaveInvoice: (invoice: Omit<Invoice, 'id' | 'createdAt'>) => void;
}

const InvoiceForm: React.FC<InvoiceFormProps> = ({ patients, onSaveInvoice }) => {
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [invoiceItems, setInvoiceItems] = useState<InvoiceItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [doctorCode, setDoctorCode] = useState('');
  const { toast } = useToast();

  const filteredItems = medicalItems.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const addItem = (item: MedicalItem) => {
    const existingItem = invoiceItems.find(invItem => invItem.itemId === item.id);
    
    if (existingItem) {
      setInvoiceItems(prevItems =>
        prevItems.map(invItem =>
          invItem.itemId === item.id
            ? {
                ...invItem,
                quantity: invItem.quantity + 1,
                totalPrice: (invItem.quantity + 1) * invItem.unitPrice
              }
            : invItem
        )
      );
    } else {
      const newItem: InvoiceItem = {
        itemId: item.id,
        itemName: item.name,
        quantity: 1,
        unitPrice: item.price,
        insuranceShare: 0,
        totalPrice: item.price
      };
      setInvoiceItems(prev => [...prev, newItem]);
    }
    
    setSearchTerm('');
    toast({
      title: "آیتم اضافه شد",
      description: `${item.name} به فاکتور اضافه شد`,
    });
  };

  const updateQuantity = (itemId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeItem(itemId);
      return;
    }

    setInvoiceItems(prevItems =>
      prevItems.map(item =>
        item.itemId === itemId
          ? {
              ...item,
              quantity: newQuantity,
              totalPrice: newQuantity * item.unitPrice
            }
          : item
      )
    );
  };

  const removeItem = (itemId: string) => {
    setInvoiceItems(prev => prev.filter(item => item.itemId !== itemId));
  };

  const calculateTotal = () => {
    return invoiceItems.reduce((sum, item) => sum + item.totalPrice, 0);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedPatient) {
      toast({
        title: "خطا",
        description: "لطفاً بیمار را انتخاب کنید",
        variant: "destructive"
      });
      return;
    }

    if (invoiceItems.length === 0) {
      toast({
        title: "خطا", 
        description: "لطفاً حداقل یک آیتم به فاکتور اضافه کنید",
        variant: "destructive"
      });
      return;
    }

    // Payment confirmation dialog
    const confirmPayment = confirm(
      `کارت کشیدین؟\nبیمار: ${selectedPatient.firstName} ${selectedPatient.lastName}\nمبلغ: ${calculateTotal().toLocaleString()} ریال`
    );

    if (confirmPayment) {
      const invoice: Omit<Invoice, 'id' | 'createdAt'> = {
        patientId: selectedPatient.id,
        items: invoiceItems,
        totalAmount: calculateTotal(),
        paymentStatus: 'paid',
        doctorCode: doctorCode || undefined
      };

      onSaveInvoice(invoice);
      
      toast({
        title: "پرداخت موفق! 💳",
        description: `مبلغ ${calculateTotal().toLocaleString()} ریال با موفقیت پرداخت شد`,
      });

      // Auto print after payment
      setTimeout(() => {
        handlePrint();
      }, 1000);
      
      // Reset form
      setSelectedPatient(null);
      setInvoiceItems([]);
      setDoctorCode('');
    }
  };

  const handlePrint = () => {
    if (!selectedPatient || invoiceItems.length === 0) {
      toast({
        title: "خطا",
        description: "برای چاپ فاکتور، ابتدا بیمار و آیتم‌ها را انتخاب کنید",
        variant: "destructive"
      });
      return;
    }

    // Create print content
    const printContent = `
      <!DOCTYPE html>
      <html dir="rtl" lang="fa">
      <head>
        <meta charset="UTF-8">
        <title>فاکتور - درمانگاه عمومی بهزاد</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 20px; direction: rtl; }
          .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; }
          .patient-info { margin-bottom: 20px; }
          .items-table { width: 100%; border-collapse: collapse; }
          .items-table th, .items-table td { border: 1px solid #333; padding: 8px; text-align: center; }
          .total { font-weight: bold; font-size: 18px; text-align: left; margin-top: 20px; }
          .footer { margin-top: 30px; text-align: center; font-size: 12px; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>درمانگاه عمومی بهزاد</h1>
          <p>فاکتور خدمات درمانی</p>
          <p>تاریخ: ${new Date().toLocaleDateString('fa-IR')}</p>
        </div>
        
        <div class="patient-info">
          <h3>اطلاعات بیمار:</h3>
          <p><strong>نام:</strong> ${selectedPatient.firstName} ${selectedPatient.lastName}</p>
          <p><strong>کد ملی:</strong> ${selectedPatient.nationalId}</p>
          <p><strong>شماره تماس:</strong> ${selectedPatient.phoneNumber}</p>
          <p><strong>نوع بیمه:</strong> ${getInsuranceLabel(selectedPatient.insuranceType || 'none')}</p>
        </div>

        <table class="items-table">
          <thead>
            <tr>
              <th>شرح خدمات/دارو</th>
              <th>تعداد</th>
              <th>قیمت واحد (ریال)</th>
              <th>قیمت کل (ریال)</th>
            </tr>
          </thead>
          <tbody>
            ${invoiceItems.map((item) => `
              <tr>
                <td>${item.itemName}</td>
                <td>${item.quantity}</td>
                <td>${item.unitPrice.toLocaleString()}</td>
                <td>${item.totalPrice.toLocaleString()}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <div class="total">
          <p>مجموع کل: ${calculateTotal().toLocaleString()} ریال</p>
        </div>

        <div class="footer">
          <p>درمانگاه عمومی بهزاد - سیستم مدیریت بیماران</p>
          ${doctorCode ? `<p>کد پزشک: ${doctorCode}</p>` : ''}
        </div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const getInsuranceLabel = (type: string) => {
    switch (type) {
      case 'social': return 'تامین اجتماعی';
      case 'health': return 'بیمه سلامت';
      case 'military': return 'نیروهای مسلح';
      case 'none': return 'فاقد بیمه';
      default: return 'نامشخص';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="shadow-card">
        <CardHeader>
          <CardTitle className="flex items-center text-right">
            <FileText className="w-5 h-5 ml-2" />
            صدور فاکتور جدید
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Patient Selection */}
            <div className="space-y-2">
              <Label>انتخاب بیمار *</Label>
              <Select 
                value={selectedPatient?.id || ''} 
                onValueChange={(value) => {
                  const patient = patients.find(p => p.id === value);
                  setSelectedPatient(patient || null);
                }}
              >
                <SelectTrigger className="text-right">
                  <SelectValue placeholder="بیمار را انتخاب کنید" />
                </SelectTrigger>
                <SelectContent>
                  {patients.map((patient) => (
                    <SelectItem key={patient.id} value={patient.id}>
                      {patient.firstName} {patient.lastName} - {patient.nationalId}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Selected Patient Info */}
            {selectedPatient && (
              <Card className="p-4 bg-muted/50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-primary rounded-full flex items-center justify-center">
                    <User className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold">{selectedPatient.firstName} {selectedPatient.lastName}</h3>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>کد ملی: {selectedPatient.nationalId}</span>
                      <span>تلفن: {selectedPatient.phoneNumber}</span>
                      <Badge className="flex items-center gap-1">
                        <Shield className="w-3 h-3" />
                        {getInsuranceLabel(selectedPatient.insuranceType || 'none')}
                      </Badge>
                    </div>
                  </div>
                </div>
              </Card>
            )}

            {/* Doctor Code */}
            <div className="space-y-2">
              <Label htmlFor="doctorCode">کد پزشک (اختیاری)</Label>
              <Input
                id="doctorCode"
                value={doctorCode}
                onChange={(e) => setDoctorCode(e.target.value)}
                placeholder="کد پزشک جهت اتصال به سامانه بیمه"
                className="text-right"
                dir="rtl"
              />
            </div>

            {/* Add Items */}
            <div className="space-y-2">
              <Label>جستجو و اضافه کردن خدمات/دارو</Label>
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="نام دارو یا خدمت را جستجو کنید..."
                className="text-right"
                dir="rtl"
              />
              
              {searchTerm && (
                <Card className="max-h-48 overflow-y-auto">
                  <CardContent className="p-2">
                    {filteredItems.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between p-2 hover:bg-muted rounded cursor-pointer"
                        onClick={() => addItem(item)}
                      >
                        <div>
                          <span className="font-medium">{item.name}</span>
                          <Badge variant="outline" className="mr-2">
                            {item.category === 'medicine' ? 'دارو' : 'خدمت'}
                          </Badge>
                        </div>
                        <span className="font-semibold">{item.price.toLocaleString()} ریال</span>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Invoice Items */}
            {invoiceItems.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">آیتم‌های فاکتور</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {invoiceItems.map((item) => (
                    <div key={item.itemId} className="flex items-center justify-between p-3 border rounded">
                      <div className="flex-1">
                        <span className="font-medium">{item.itemName}</span>
                        <div className="text-sm text-muted-foreground">
                          قیمت واحد: {item.unitPrice.toLocaleString()} ریال
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          onClick={() => updateQuantity(item.itemId, item.quantity - 1)}
                        >
                          <Minus className="w-3 h-3" />
                        </Button>
                        <span className="w-8 text-center">{item.quantity}</span>
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          onClick={() => updateQuantity(item.itemId, item.quantity + 1)}
                        >
                          <Plus className="w-3 h-3" />
                        </Button>
                        <span className="w-20 text-left font-semibold">
                          {item.totalPrice.toLocaleString()}
                        </span>
                        <Button
                          type="button"
                          size="sm"
                          variant="ghost"
                          onClick={() => removeItem(item.itemId)}
                          className="text-destructive"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                  
                  <div className="flex justify-between items-center pt-4 border-t font-bold text-lg">
                    <span>مجموع کل:</span>
                    <span>{calculateTotal().toLocaleString()} ریال</span>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Actions */}
            <div className="flex gap-2 justify-end">
              <Button
                type="button"
                variant="outline"
                onClick={handlePrint}
                disabled={!selectedPatient || invoiceItems.length === 0}
              >
                <Printer className="w-4 h-4 ml-2" />
                چاپ فاکتور
              </Button>
              <Button
                type="submit"
                className="bg-gradient-primary hover:opacity-90 text-white"
                disabled={!selectedPatient || invoiceItems.length === 0}
              >
                <Calculator className="w-4 h-4 ml-2" />
                ثبت فاکتور
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default InvoiceForm;