import { MedicalItem } from '@/types';

export const medicalItems: MedicalItem[] = [
  // خدمات ویزیت و معاینه
  { id: '1', name: 'ویزیت عمومی بالای 15 سال', price: 2600000, category: 'service' },
  { id: '2', name: 'ویزیت عمومی زیر 15 سال', price: 2300000, category: 'service' },
  { id: '3', name: 'ویزیت متخصص', price: 3300000, category: 'service' },
  { id: '4', name: 'ویزیت فوق تخصص', price: 4000000, category: 'service' },
  { id: '5', name: 'ویزیت در منزل', price: 3000000, category: 'service' },
  
  // خدمات درمانی و تزریقات
  { id: '6', name: 'سرم تراپی', price: 1300000, category: 'service' },
  { id: '7', name: 'سرم تراپی در منزل', price: 4000000, category: 'service' },
  { id: '8', name: 'تزریق داخل سرم', price: 300000, category: 'service' },
  { id: '9', name: 'تزریق عضلانی', price: 500000, category: 'service' },
  { id: '10', name: 'تزریق آنتی بیوتیک', price: 500000, category: 'service' },
  { id: '11', name: 'تزریق زیر جلدی', price: 500000, category: 'service' },
  { id: '12', name: 'تزریق وریدی', price: 900000, category: 'service' },
  { id: '13', name: 'تزریقات در منزل', price: 750000, category: 'service' },
  
  // تست ها و معاینات
  { id: '14', name: 'تست آنتی بیوتیک', price: 300000, category: 'service' },
  { id: '15', name: 'گرفتن فشار خون', price: 500000, category: 'service' },
  { id: '16', name: 'گرفتن قند خون', price: 500000, category: 'service' },
  { id: '17', name: 'نوار قلب', price: 1700000, category: 'service' },
  
  // خدمات جراحی و درمانی
  { id: '18', name: 'فصد خون', price: 2000000, category: 'service' },
  { id: '19', name: 'خارج کردن پلیسه', price: 2000000, category: 'service' },
  { id: '20', name: 'شستشوی گوش (هر عدد)', price: 2000000, category: 'service' },
  { id: '21', name: 'سوراخ کردن گوش', price: 2500000, category: 'service' },
  { id: '22', name: 'گوشواره (جفتی)', price: 900000, category: 'service' },
  { id: '23', name: 'کشیدن ناخن', price: 5000000, category: 'service' },
  { id: '24', name: 'پانسمان', price: 1000000, category: 'service' },
  { id: '25', name: 'پانسمان', price: 1500000, category: 'service' },
  { id: '26', name: 'بخیه (هر عدد)', price: 0, category: 'service' }, // طبق نظر پزشک
  { id: '27', name: 'کشیدن بخیه', price: 2500000, category: 'service' },
  { id: '28', name: 'ختنه با حلقه', price: 15000000, category: 'service' },
  { id: '29', name: 'اکسیژن', price: 1500000, category: 'service' },
  
  // داروهای کورتیکواستروئیدی
  { id: '30', name: 'دگزامتازون', price: 210000, category: 'medicine' },
  { id: '31', name: 'بتامتازون', price: 210000, category: 'medicine' },
  { id: '32', name: 'بتامتازون ال آ', price: 230000, category: 'medicine' },
  { id: '33', name: 'هیدروکورتیزون', price: 350000, category: 'medicine' },
  { id: '34', name: 'تریامسینولون', price: 210000, category: 'medicine' },
  { id: '35', name: 'متیل پردنیزولون', price: 210000, category: 'medicine' },
  
  // داروهای ماهیچه ای و گوارشی
  { id: '36', name: 'متوکاربامول', price: 450000, category: 'medicine' },
  { id: '37', name: 'اندانسترون', price: 210000, category: 'medicine' },
  { id: '38', name: 'پنتوپرازول', price: 350000, category: 'medicine' },
  { id: '39', name: 'متوکلوپرامید', price: 210000, category: 'medicine' },
  { id: '40', name: 'دیسیکلومین', price: 210000, category: 'medicine' },
  { id: '41', name: 'فاموتیدین', price: 210000, category: 'medicine' },
  
  // آنتی بیوتیک ها
  { id: '42', name: 'آمپی سیلین', price: 450000, category: 'medicine' },
  { id: '43', name: 'سفازولین ۵۰۰', price: 350000, category: 'medicine' },
  { id: '44', name: 'سفازولین ۱', price: 450000, category: 'medicine' },
  { id: '45', name: 'پنی سیلین ۶/۳/۳', price: 450000, category: 'medicine' },
  { id: '46', name: 'پنی سیلین ۸۰۰', price: 600000, category: 'medicine' },
  { id: '47', name: 'پنی سیلین ۱۲۰۰', price: 300000, category: 'medicine' },
  { id: '48', name: 'سفتری اکسون ۵۰۰', price: 160000, category: 'medicine' },
  { id: '49', name: 'سفتری اکسون ۱', price: 160000, category: 'medicine' },
  { id: '50', name: 'جنتامایسین', price: 60000, category: 'medicine' },
  
  // داروهای مختلف
  { id: '51', name: 'آتروپین', price: 100000, category: 'medicine' },
  { id: '52', name: 'ب کمپلکس', price: 210000, category: 'medicine' },
  { id: '53', name: 'B12', price: 210000, category: 'medicine' },
  { id: '54', name: 'نوروبیون', price: 250000, category: 'medicine' },
  { id: '55', name: 'ویتامین C', price: 250000, category: 'medicine' },
  { id: '56', name: 'D3', price: 210000, category: 'medicine' },
  { id: '57', name: 'ویتامین K', price: 300000, category: 'medicine' },
  { id: '58', name: 'آب مقطر', price: 350000, category: 'medicine' },
  { id: '59', name: 'کترولاک', price: 250000, category: 'medicine' },
  { id: '60', name: 'پیروکسیکام', price: 210000, category: 'medicine' },
  { id: '61', name: 'کلرفنیرامین', price: 210000, category: 'medicine' },
  { id: '62', name: 'پرومتازین', price: 210000, category: 'medicine' },
  { id: '63', name: 'فنوباربیتال', price: 210000, category: 'medicine' },
  { id: '64', name: 'کاربامازپین', price: 210000, category: 'medicine' },
  { id: '65', name: 'دیازپام', price: 450000, category: 'medicine' },
  { id: '66', name: 'هالوپریدول', price: 350000, category: 'medicine' },
  { id: '67', name: 'بایپریدین', price: 400000, category: 'medicine' },
  { id: '68', name: 'تریفلوپرازین', price: 350000, category: 'medicine' },
  { id: '69', name: 'فوروزماید', price: 300000, category: 'medicine' },
  { id: '70', name: 'آمینوفیلین', price: 350000, category: 'medicine' },
  { id: '71', name: 'پروپرانولول', price: 0, category: 'medicine' },
  { id: '72', name: 'وراپامیل', price: 0, category: 'medicine' },
  { id: '73', name: 'پروژسترون', price: 380000, category: 'medicine' },
  { id: '74', name: 'سرنگ انسولین', price: 250000, category: 'medicine' },
  { id: '75', name: 'آمیودارون', price: 210000, category: 'medicine' },
  { id: '76', name: 'هپارین', price: 450000, category: 'medicine' },
  { id: '77', name: 'دوپامین', price: 0, category: 'medicine' },
  { id: '78', name: 'آسیکلوویر', price: 0, category: 'medicine' },
  { id: '79', name: 'انسولین رگولار', price: 0, category: 'medicine' },
  { id: '80', name: 'لیدوکائین', price: 250000, category: 'medicine' },
  
  // سرم ها
  { id: '81', name: 'سرم نرمالسالین ۵۰۰', price: 80000, category: 'medicine' },
  { id: '82', name: 'سرم نرمالسالین ۱', price: 350000, category: 'medicine' },
  { id: '83', name: 'سرم قندی نمکی ۵۰۰', price: 400000, category: 'medicine' },
  { id: '84', name: 'سرم قندی نمکی ۱', price: 400000, category: 'medicine' },
  { id: '85', name: 'سرم هافسالین ۵۰۰', price: 450000, category: 'medicine' },
  { id: '86', name: 'سرم هافسالین ۱', price: 350000, category: 'medicine' },
  { id: '87', name: 'سرم دکستروز ۵۰۰', price: 400000, category: 'medicine' },
  { id: '88', name: 'سرم دکستروز ۱', price: 450000, category: 'medicine' },
  { id: '89', name: 'سرم رینگر ۵۰۰', price: 450000, category: 'medicine' },
  { id: '90', name: 'سرم شستشو', price: 600000, category: 'medicine' },
  
  // لوازم پزشکی
  { id: '91', name: 'ست سرم', price: 210000, category: 'medicine' },
  { id: '92', name: 'آنژیوکت آبی', price: 210000, category: 'medicine' },
  { id: '93', name: 'آنژیوکت زرد', price: 160000, category: 'medicine' },
  { id: '94', name: 'سرنگ ۳', price: 60000, category: 'medicine' },
  { id: '95', name: 'سرنگ ۱۰', price: 100000, category: 'medicine' },
  { id: '96', name: 'سرنگ ۲۰', price: 200000, category: 'medicine' },
  { id: '97', name: 'استامینوفن', price: 350000, category: 'medicine' },
];