import React, { useState, useEffect } from 'react';
import MainLayout from '@/components/layout/main-layout';
import SimplifiedInvoiceForm from '@/components/invoice/simplified-invoice-form';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Invoice } from '@/types';
import { useToast } from '@/hooks/use-toast';
import { BarChart3 } from 'lucide-react';

interface ClinicAppProps {
  receptionist: string;
}

const ClinicApp: React.FC<ClinicAppProps> = ({ receptionist }) => {
  const [activeTab, setActiveTab] = useState('invoice');
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const { toast } = useToast();

  // Load data from localStorage on component mount
  useEffect(() => {
    const savedInvoices = localStorage.getItem('clinic-invoices');
    
    if (savedInvoices) {
      try {
        setInvoices(JSON.parse(savedInvoices));
      } catch (error) {
        console.error('Error loading invoices:', error);
      }
    }
  }, []);

  // Save data to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('clinic-invoices', JSON.stringify(invoices));
  }, [invoices]);

  const handleSaveInvoice = (invoiceData: Omit<Invoice, 'id' | 'createdAt'>) => {
    const newInvoice: Invoice = {
      ...invoiceData,
      id: Date.now().toString(),
      createdAt: new Date(),
    };
    setInvoices(prev => [...prev, newInvoice]);
  };

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };

  const renderContent = () => {
    if (activeTab === 'management') {
      return (
        <Card className="shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center text-right">
              <BarChart3 className="w-5 h-5 ml-2" />
              مدیریت فاکتورها
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {invoices.length === 0 ? (
                <div className="text-center text-muted-foreground py-8">
                  هنوز فاکتوری ثبت نشده است
                </div>
              ) : (
                <div className="grid gap-4">
                  {invoices.map((invoice) => (
                    <Card key={invoice.id} className="p-4">
                      <div className="flex justify-between items-center">
                        <div className="text-right">
                          <p className="font-semibold">
                            فاکتور شماره {invoice.id}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            تاریخ: {invoice.createdAt.toLocaleDateString('fa-IR')}
                          </p>
                          <p className="text-sm font-medium">
                            مجموع: {invoice.totalAmount.toLocaleString()} ریال
                          </p>
                        </div>
                        <div className="text-left">
                          <p className="text-sm text-muted-foreground">
                            {invoice.items.length} مورد
                          </p>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      );
    }

    return <SimplifiedInvoiceForm onSaveInvoice={handleSaveInvoice} receptionist={receptionist} />;
  };

  return (
    <MainLayout
      activeTab={activeTab}
      onTabChange={handleTabChange}
    >
      {renderContent()}
    </MainLayout>
  );
};

export default ClinicApp;