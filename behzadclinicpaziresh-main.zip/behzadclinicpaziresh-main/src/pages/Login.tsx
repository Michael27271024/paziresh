import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Stethoscope, Lock, UserCheck } from 'lucide-react';

interface LoginProps {
  onLogin: (success: boolean, receptionist: string) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [password, setPassword] = useState('');
  const [receptionist, setReceptionist] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!receptionist) {
      toast({
        title: "خطا",
        description: "لطفاً پذیرش دهنده را انتخاب کنید",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      if (password === 'avesta27admin') {
        onLogin(true, receptionist);
        toast({
          title: "ورود موفق",
          description: `خوش آمدید ${receptionist}`,
        });
      } else {
        toast({
          title: "خطا در ورود",
          description: "رمز عبور اشتباه است",
          variant: "destructive",
        });
      }
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-medical border-0 bg-card/80 backdrop-blur-sm">
        <CardHeader className="text-center space-y-2">
          <div className="flex justify-center">
            <div className="p-3 bg-gradient-primary rounded-full shadow-lg">
              <Stethoscope className="w-8 h-8 text-primary-foreground" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            سیستم مدیریت درمانگاه بهزاد
          </CardTitle>
          <CardDescription className="text-muted-foreground">
            برای ورود رمز عبور را وارد کنید
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="receptionist" className="text-right flex items-center">
                <UserCheck className="w-4 h-4 ml-1" />
                پذیرش دهنده
              </Label>
              <Select value={receptionist} onValueChange={setReceptionist}>
                <SelectTrigger className="text-right" dir="rtl">
                  <SelectValue placeholder="پذیرش دهنده را انتخاب کنید" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="مریم پورصالحی">مریم پورصالحی</SelectItem>
                  <SelectItem value="سوگند دادجو">سوگند دادجو</SelectItem>
                  <SelectItem value="شهلا آرزومند">شهلا آرزومند</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-right flex items-center">
                <Lock className="w-4 h-4 ml-1" />
                رمز عبور
              </Label>
              <Input
                id="password"
                type="password"
                placeholder="رمز عبور را وارد کنید"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="text-right"
                required
              />
            </div>
            <Button 
              type="submit" 
              className="w-full bg-gradient-primary hover:opacity-90 transition-all"
              disabled={isLoading}
            >
              {isLoading ? 'در حال بررسی...' : 'ورود'}
            </Button>
          </form>
        </CardContent>
      </Card>
      
      <div className="absolute bottom-4 left-4 right-4 text-center">
        <p className="text-xs text-muted-foreground">
          تمام حقوق محفوظ به درمانگاه بهزاد - سازنده: اوستا حسن زاده
        </p>
      </div>
    </div>
  );
};

export default Login;