import React, { useState } from 'react';
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "../components/theme-provider";
import ClinicApp from './clinic-app';
import Login from './Login';

const Index = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [receptionist, setReceptionist] = useState('');

  const handleLogin = (success: boolean, receptionistName: string) => {
    setIsLoggedIn(success);
    setReceptionist(receptionistName);
  };

  return (
    <ThemeProvider defaultTheme="system" storageKey="ui-theme">
      <Toaster />
      {isLoggedIn ? <ClinicApp receptionist={receptionist} /> : <Login onLogin={handleLogin} />}
    </ThemeProvider>
  );
};

export default Index;