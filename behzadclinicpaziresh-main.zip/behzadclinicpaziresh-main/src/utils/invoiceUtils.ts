// Utility functions for invoice management

export const generateDailyInvoiceNumber = (): string => {
  const today = new Date().toDateString();
  const storageKey = `invoice-counter-${today}`;
  
  // Get current counter for today
  const currentCounter = localStorage.getItem(storageKey);
  const counter = currentCounter ? parseInt(currentCounter) + 1 : 1;
  
  // Save updated counter
  localStorage.setItem(storageKey, counter.toString());
  
  // Format: YYYYMMDD-XX (e.g., 20241207-01)
  const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  return `${dateStr}-${counter.toString().padStart(2, '0')}`;
};

export const calculateInsuranceShare = (itemName: string, insuranceType: string): number => {
  // Insurance only applies to general doctor visits (ویزیت عمومی)
  if (!itemName.includes('ویزیت عمومی')) {
    return 0;
  }
  
  switch (insuranceType) {
    case 'social':
      return 720000; // تامین اجتماعی
    case 'health':
      return 720000; // سلامت
    case 'military':
      return 185000; // نیروهای مسلح
    case 'military_disabled':
      return itemName.includes('ویزیت عمومی زیر 15 سال') ? 2300000 : 2600000; // نیروهای مسلح جانباز - کامل
    case 'bank':
      return itemName.includes('ویزیت عمومی زیر 15 سال') ? 2300000 : 2600000; // بانک ها - کامل
    default:
      return 0; // فاقد بیمه
  }
};

export const getInsuranceTypeName = (type: string): string => {
  switch (type) {
    case 'social':
      return 'تامین اجتماعی';
    case 'health':
      return 'سلامت';
    case 'military':
      return 'نیروهای مسلح';
    case 'military_disabled':
      return 'نیروهای مسلح جانباز';
    case 'bank':
      return 'بانک ها';
    default:
      return 'فاقد بیمه';
  }
};